package application.contracts;

import java.util.LinkedHashMap;

public interface HttpRequest {

    LinkedHashMap<String, String> getHeaders();

    LinkedHashMap<String, String> getBodyParameters();

    String getMethod();

    void setMethod(String method);

    String getRequestUrl();

    void setRequestUrl(String requestUrl);

    void addHeaders(String headers, String value);

    void addBodyParameters(String parameter, String value);

    boolean isResource();

}
